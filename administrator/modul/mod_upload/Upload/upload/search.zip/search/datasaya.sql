-- phpMyAdmin SQL Dump
-- version 4.0.6deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 24, 2014 at 02:21 PM
-- Server version: 5.5.34-0ubuntu0.13.10.1
-- PHP Version: 5.5.3-1ubuntu2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `datasaya`
--
CREATE DATABASE IF NOT EXISTS `datasaya` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `datasaya`;

-- --------------------------------------------------------

--
-- Table structure for table `situs`
--

CREATE TABLE IF NOT EXISTS `situs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL,
  `keyword` varchar(200) NOT NULL,
  `url` varchar(225) NOT NULL,
  `pemilik` varchar(45) NOT NULL,
  `tgl` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `situs`
--

INSERT INTO `situs` (`id`, `judul`, `deskripsi`, `keyword`, `url`, `pemilik`, `tgl`) VALUES
(1, 'Belajar Bahasa Pemrograman', 'belajar bahasa komputer sangat mudah tinggal ada kemauan dari anda dan dengan bahasa pemrograman atau bahasa komputer kita dapat membuat sebuah program yang mana nantinya akan digunakan untuk perusahaan anda', 'pemrograman, komputer, belajar', 'http://www.velkam.com/belajar-pemrograman.html', 'Jefry', '2014-02-24 20:27:14'),
(2, 'Belajar Akuntansi', 'belajar akuntansi sangat mudah tinggal ada kemauan dari anda dan dengan akuntansi kita dapat membuat sebuah bentuk perhitungan keuangan yang mana nantinya akan digunakan untuk perusahaan anda', 'akuntansi, belajar', 'http://www.kuntansi.co.id/bsukses-akuntansi.html', 'JRaffi', '2014-02-24 20:29:52'),
(3, 'Belajar Bahasa Inggris', 'belajar bahasa inggris sangat mudah tinggal ada kemauan dari anda dan dengan bahasa inggris atau bahasa asing kita dapat membuat sebuah percakapan dengan orang luar yang mana nantinya akan digunakan untuk perusahaan anda', 'inggris, belajar', 'http://www.engbel.com/belajar-inggris.html', 'Novita', '2014-02-24 20:32:21'),
(4, 'Belajar Bahasa Pemrograman', 'belajar bahasa komputer sangat mudah tinggal ada kemauan dari anda dan dengan bahasa pemrograman atau bahasa komputer kita dapat membuat sebuah program yang mana nantinya akan digunakan untuk perusahaan anda', 'pemrograman, komputer, belajar', 'http://www.pemrograman.com/belajar-pemrograman.html', 'Jefry', '2014-02-24 20:32:54');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
mysql_connect('localhost','root','kodokijo')or die("gagal koneksi");
mysql_select_db('datasaya')or die("tidak ada database");
?>
